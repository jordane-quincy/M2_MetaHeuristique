Explication pour executer le programme:

Afin d'ex�cuter le programme, il faut d�zipper l'archive "TP_Metaheuristique_DEGRES_DURIEZ_QUINCY_sources.zip" dans un dossier

Sous linux : Il faut se positionner dans le dossier o� l'archive a �t� d�zipp�e (grace � la console) puis taper "make" dans la console afin d'executer le makefile
puis pour ex�cuter le programme il faut taper miniprojet_1dans la console puis les arguments, le programme se lance
(Il y a des warning lors du make mais ils n'emp�chent pas l'ex�cution du programme)

Sous windows : (V�rifier que MinGW est bien install� et que MinGW/bin est pr�sent dans la variable PATH)
Il faut se positionner dans le dossier o� l'archive a �t� d�zipp�e (grace � la console) puis taper "mingw32-make" dans la console afin d'ex�cuter le makefile
puis pour ex�cuter le programme il faut taper miniprojet_1 dans la console avec les arguments, le programme se lance
(Il y a des warning lors du make mais ils n'emp�chent pas l'ex�cution du programme)

Comme voulu d'apr�s le sujet, il y a 3 arguments � ajouter au lancement du programme.
1er argument : chemin de l'instance
2�me argument : fichier de sortie
3�me argument : temps accord� en secondes